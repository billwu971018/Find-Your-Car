<!DOCTYPE html>
<html lang="en">
<head>
  <title>Car Finder</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="js/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script src="js/jquery.min.js"></script>
  <script src="/js/my.js"></script>

<style>
body {
    background-color: #343a40;
}

.container{
   max-width: 1400px; //Or whatever value you need
}
 

</style>




</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Car Finder</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav mr-auto">
      <a class="nav-item nav-link active" href="#">Home <span class="sr-only">(current)</span></a>
      <a class="nav-item nav-link" href="#">Features</a>
      <a class="nav-item nav-link" href="#">Pricing</a>
      <a class="nav-item nav-link disabled" href="#">Disabled</a>
    </div>
    <div class="navbar-nav ml-auto">
      <a class="nav-item nav-link" href="login-d.html">Dealer Login</a>
        <a class="nav-item nav-link" href="login.html">Login</a>
    </div>
  </div>
</nav> 



<br>
<br>
<div class="container"  >
    <!-- Content here -->
  <div class="row">
    <!--<div class="col-md-2">
        <br>
        <br>
        <h1 align="center"><font color = "white">Hot Selling</font></h1>
        <h1 align="center"><font color = "white">Cars</font></h1>
    
    </div>-->
    <div class="row">
<?php
  function __autoload($a){
    if(is_file("$a.class.php")){
      include_once "$a.class.php";
    }
  };
  $db = new DB(array('dbname' => 'car'));
  $sql="select DISTINCT CarId from favorite  where UserId=".$_GET['UserId'];
  //echo $sql;
  $res=$db->db_getAll($sql);
  //var_dump($res);
  if($res){
    foreach ($res as $value) {
		$sql="select * from carinformation  where CarId=".$value['CarId'];
		//echo $sql;
		$res2=$db->db_getAll($sql);
		foreach ($res2 as $value2) {
			echo '<div class="card" style="width: 22rem;">

            <img class="card-img-top" src="images/car.jpg" alt="Card image cap">
            <div class="card-body">
            <h3 class="detail-h3">
            <i class="am-icon-mobile am-icon-sm"></i>'.$value2['Make'].'/'.$value2['Model'].'</h3>
            <h5 class="detail-p">Price: $'.$value2['Price'].'</h5>
            <p class="detail-p">Color: '.$value2['Color'].'</p>
            <p class="card-text">NewOrUsed: '.$value2['NewOrUsed'].'</p>
            <a href="car-content.php?id='.$value2['CarId'].'" class="btn btn-primary">Enter</a>
            </div>
        </div>';
		}
		
      
    }
  }else{
    echo "No Data!";
  }
  ?>
        
        
  </div>
  </div>
  
</div>
<div class="container">
    <!-- Content here -->
  <div class="row">
    <div class="col-md-2">
    
    </div>
    <div class="row">
    
        
  </div>
  </div>
  
</div>



<div class="container">
  <!-- Content here -->
    <h1 class="display-4">Hello, world!</h1>
  <p class="lead">This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
  <hr class="my-4">
  <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
  <p class="lead">
    <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
  </p>
</div>



<!--
<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <h3>Column 1</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
      <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
    </div>
    <div class="col-sm-4">
      <h3>Column 2</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
      <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
    </div>
    <div class="col-sm-4">
      <h3>Column 3</h3>        
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
      <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
    </div>
  </div>
</div>
-->


</body>
</html>
